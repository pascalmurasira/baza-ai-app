import { useRef, useCallback } from 'react';

function decode(base64: string): Uint8Array {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}


export function useAudioPlayback() {
  const audioContextRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

  const getAudioContext = useCallback(() => {
    if (!audioContextRef.current || audioContextRef.current.state === 'closed') {
      // Use global type definition for webkitAudioContext
      audioContextRef.current = new (window.AudioContext || window.webkitAudioContext)({ sampleRate: 24000 });
      nextStartTimeRef.current = 0;
      sourcesRef.current.clear();
    }
    
    // Robustness: Handle suspended audio context (e.g., after long inactivity).
    // The browser may suspend the audio context to save power. This ensures it resumes.
    if (audioContextRef.current.state === 'suspended') {
      audioContextRef.current.resume().catch(console.error);
    }

    return audioContextRef.current;
  }, []);

  const playAudio = useCallback(async (
    base64EncodedAudioString: string,
    onPlayStart?: () => void,
    onPlayEnd?: () => void
  ) => {
    const audioContext = getAudioContext();
    const audioData = decode(base64EncodedAudioString);

    if (audioData.length === 0) {
      onPlayEnd?.(); // If no data, end immediately
      return;
    }

    try {
      const audioBuffer = await decodeAudioData(audioData, audioContext, 24000, 1);
      const source = audioContext.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(audioContext.destination);

      const currentTime = audioContext.currentTime;
      const startTime = Math.max(currentTime, nextStartTimeRef.current);

      source.start(startTime);
      onPlayStart?.(); // Signal that playback has been scheduled/started
      nextStartTimeRef.current = startTime + audioBuffer.duration;
      
      sourcesRef.current.add(source);
      source.onended = () => {
        sourcesRef.current.delete(source);
        onPlayEnd?.(); // Signal that playback has finished
      };
    } catch (error) {
      console.error("Error playing audio:", error);
      onPlayEnd?.(); // Signal end on error
    }
  }, [getAudioContext]);
  
  const stopAllAudio = useCallback(() => {
    sourcesRef.current.forEach(source => {
      try {
        source.stop();
      } catch (e) {
        // Ignore errors if source already stopped
      }
    });
    sourcesRef.current.clear();
    nextStartTimeRef.current = 0;
    // Do NOT close the context here. This allows it to be reused, which is more performant
    // and reduces latency for subsequent playbacks. The browser will manage its lifecycle.
    // If closure is needed, it should be done on component unmount.
  }, []);


  return { playAudio, stopAllAudio };
}
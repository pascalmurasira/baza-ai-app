import { useState, useEffect, useCallback } from 'react';
import { v4 as uuidv4 } from 'uuid';
import type { Content } from '@google/genai';
import type { ChatSession, ChatMessage } from '../types';

const STORAGE_KEY = 'baza-ai-chat-history';

function loadSessionsFromStorage(): ChatSession[] {
    try {
        const storedSessions = localStorage.getItem(STORAGE_KEY);
        if (storedSessions) {
            const parsed = JSON.parse(storedSessions) as ChatSession[];
            // Sort by creation date, newest first
            return parsed.sort((a, b) => b.createdAt - a.createdAt);
        }
    } catch (error) {
        console.error("Failed to load chat sessions from storage:", error);
    }
    return [];
}

function saveSessionsToStorage(sessions: ChatSession[]) {
    try {
        // Optimization: Strip large file data before saving to localStorage to avoid quota errors.
        const sessionsForStorage = sessions.map(session => ({
            ...session,
            messages: session.messages.map(message => {
                // eslint-disable-next-line @typescript-eslint/no-unused-vars
                const { file, ...messageWithoutFile } = message;
                return messageWithoutFile;
            }),
        }));
        localStorage.setItem(STORAGE_KEY, JSON.stringify(sessionsForStorage));
    } catch (error) {
        console.error("Failed to save chat sessions to storage:", error);
    }
}

// The type for the `updates` parameter in `updateChat`
type UpdatePayload = Partial<Omit<ChatSession, 'messages'>> & {
    messages?: ChatMessage[] | ((prevMessages: ChatMessage[]) => ChatMessage[]);
};


export function useChatHistory() {
    const [sessions, setSessions] = useState<ChatSession[]>(() => loadSessionsFromStorage());
    const [currentChatId, setCurrentChatId] = useState<string | null>(null);

    // Effect to save sessions to storage with a debounce.
    useEffect(() => {
        const handler = setTimeout(() => {
            saveSessionsToStorage(sessions);
        }, 500); // Debounce save operations.

        return () => {
            clearTimeout(handler);
        };
    }, [sessions]);
    
    const handleNewChat = useCallback(() => {
        const newSession: ChatSession = {
            id: uuidv4(),
            title: "Ikiganiro Gishya",
            messages: [],
            history: [],
            createdAt: Date.now(),
        };
        // Just update state. The effect will handle saving.
        setSessions(prev => [newSession, ...prev]);
        setCurrentChatId(newSession.id);
        return newSession.id;
    }, []);
    
    // Effect to initialize or select the first chat.
    useEffect(() => {
        if (sessions.length > 0) {
            // If sessions loaded, select the first one if none valid is selected.
            if (!currentChatId || !sessions.some(s => s.id === currentChatId)) {
                setCurrentChatId(sessions[0].id);
            }
        } else {
            // If there are no sessions at all, create a new one.
            handleNewChat();
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []); 

    // Effect to handle deletion of the current chat or if no chat is selected.
    useEffect(() => {
        const currentChatExists = sessions.some(s => s.id === currentChatId);
        if (sessions.length > 0 && !currentChatExists) {
            setCurrentChatId(sessions[0].id);
        } else if (sessions.length === 0) {
            handleNewChat();
        }
    }, [sessions, currentChatId, handleNewChat]);


    const selectChat = useCallback((id: string) => {
        setCurrentChatId(id);
    }, []);

    const updateChat = useCallback((id: string, updates: UpdatePayload) => {
        setSessions(prevSessions => {
            const sessionIndex = prevSessions.findIndex(session => session.id === id);
            if (sessionIndex === -1) return prevSessions;

            const sessionToUpdate = prevSessions[sessionIndex];
            
            const newMessages = typeof updates.messages === 'function'
                ? updates.messages(sessionToUpdate.messages)
                : updates.messages;

            const updatedSession = {
                ...sessionToUpdate,
                ...updates,
                ...(newMessages !== undefined && { messages: newMessages }),
            };
            
            const otherSessions = prevSessions.filter(s => s.id !== id);
            return [updatedSession, ...otherSessions]; // Just return new state
        });
    }, []);

    const deleteChat = useCallback((id: string) => {
        setSessions(prevSessions => {
            return prevSessions.filter(session => session.id !== id); // Just return new state
        });
    }, []);
    
    const currentSession = sessions.find(s => s.id === currentChatId);

    return {
        sessions,
        currentChatId,
        currentSession,
        newChat: handleNewChat,
        selectChat,
        updateChat,
        deleteChat,
    };
}
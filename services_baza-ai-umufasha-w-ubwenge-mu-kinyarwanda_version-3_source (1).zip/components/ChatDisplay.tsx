import React, { useEffect, useRef, useState, useMemo } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import type { ChatMessage } from '../types';
import { CopyIcon, RefreshIcon, CheckIcon, SearchIcon } from './icons';
import ThinkingIndicator from './ThinkingIndicator';
import WelcomePlaceholder from './WelcomePlaceholder';

interface ChatDisplayProps {
    messages: ChatMessage[];
    onRetry: (messageId: string) => void;
    onRegenerate: () => void;
    onSuggestedQuestionClick: (question: string) => void;
    isSending: boolean;
}

const CodeBlock: React.FC<any> = ({ node, inline, className, children, ...props }) => {
    const [isCopied, setIsCopied] = useState(false);
    const match = /language-(\w+)/.exec(className || '');
    const codeText = String(children).replace(/\n$/, '');

    const handleCopy = () => {
        navigator.clipboard.writeText(codeText).then(() => {
            setIsCopied(true);
            setTimeout(() => setIsCopied(false), 2000);
        });
    };

    return !inline ? (
        <div className="code-block-wrapper my-4">
            <pre className="prose dark:prose-invert" {...props}>
                <code>{children}</code>
            </pre>
            <button onClick={handleCopy} className="copy-code-btn" title="Koporora kode">
                {isCopied ? 'Byakoporowe!' : 'Koporora'}
            </button>
        </div>
    ) : (
        <code className={className} {...props}>
            {children}
        </code>
    );
};

interface ChatMessageItemProps {
    message: ChatMessage;
    isLastModelMessage: boolean;
    isSending: boolean;
    onRetry: (messageId: string) => void;
    onRegenerate: () => void;
    onSuggestedQuestionClick: (question: string) => void;
}

const ChatMessageItem: React.FC<ChatMessageItemProps> = ({ 
    message, isLastModelMessage, isSending, 
    onRetry, onRegenerate, onSuggestedQuestionClick 
}) => {
    
    const isUser = message.role === 'user';
    const [isCopied, setIsCopied] = useState(false);

    const handleCopy = () => {
        const textToCopy = message.role === 'model'
            ? message.text.split('[SUGGESTIONS]')[0].trim()
            : message.text;

        navigator.clipboard.writeText(textToCopy).then(() => {
            setIsCopied(true);
            setTimeout(() => setIsCopied(false), 2000);
        });
    };

    const { mainResponse, suggestions } = useMemo(() => {
        if (message.role === 'model' && message.text.includes('[SUGGESTIONS]')) {
            const parts = message.text.split('[SUGGESTIONS]');
            const response = parts[0].trim();
            const suggestionLines = parts[1]
                .split('\n')
                .map(line => line.trim())
                .filter(line => line.startsWith('* '))
                .map(line => line.substring(2).trim());
            return { mainResponse: response, suggestions: suggestionLines };
        }
        return { mainResponse: message.text, suggestions: [] };
    }, [message.text, message.role]);

    const hasFooterContent = (message.groundingChunks && message.groundingChunks.length > 0) || (isLastModelMessage && !isSending && suggestions.length > 0);

    return (
        <div className={`chat-message-container group relative flex gap-3 ${isUser ? 'justify-end' : ''}`}>
            {!isUser && (
                <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-white font-bold flex-shrink-0">
                    B
                </div>
            )}

            <div className={`w-full max-w-xl p-3 rounded-xl relative ${isUser ? 'bg-blue-50 dark:bg-slate-800' : 'bg-slate-100 dark:bg-slate-700/50'}`}>
                <div className="prose prose-sm dark:prose-invert max-w-none">
                    {message.file && (
                        <div className="mb-2">
                            <img src={message.file.dataUrl} alt={message.file.name} className="max-w-xs max-h-48 rounded-lg" />
                        </div>
                    )}
                    {message.status === 'pending' && !mainResponse ? (
                        <ThinkingIndicator />
                    ) : mainResponse ? (
                        <>
                            <ReactMarkdown
                                remarkPlugins={[remarkGfm]}
                                components={{ code: CodeBlock }}
                            >
                                {mainResponse}
                            </ReactMarkdown>
                            {message.status === 'pending' && <span className="blinking-cursor"></span>}
                        </>
                    ) : null}
                </div>

                {/* Unified Toolbar */}
                {message.status === 'complete' && (
                    <div className="absolute bottom-2 right-2 flex items-center gap-1 p-1 rounded-lg bg-slate-200/50 dark:bg-slate-900/50 backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                        <button 
                            onClick={handleCopy} 
                            className="p-1.5 rounded-md hover:bg-slate-300 dark:hover:bg-slate-700" 
                            title="Koporora ubutumwa"
                        >
                            {isCopied ? <CheckIcon className="w-4 h-4 text-green-500" /> : <CopyIcon className="w-4 h-4 text-slate-600 dark:text-slate-300" />}
                        </button>
                        {message.role === 'model' && isLastModelMessage && !isSending && (
                             <button 
                                onClick={onRegenerate} 
                                className="p-1.5 rounded-md hover:bg-slate-300 dark:hover:bg-slate-700" 
                                title="Ongera usubize"
                             >
                                <RefreshIcon className="w-4 h-4 text-slate-600 dark:text-slate-300" />
                            </button>
                        )}
                    </div>
                )}

                {/* Footer for sources and suggestions */}
                {hasFooterContent && (
                    <div className="mt-4 pt-3 border-t border-slate-200 dark:border-slate-600 space-y-4">
                        {/* Grounding Sources */}
                        {message.groundingChunks && message.groundingChunks.length > 0 && (
                            <div>
                                <h4 className="text-xs font-semibold text-slate-600 dark:text-slate-400 mb-2 flex items-center gap-2">
                                    <SearchIcon className="w-4 h-4" />
                                    Amakuru yavuye kuri:
                                </h4>
                                <ol className="list-decimal list-inside text-sm space-y-1">
                                    {message.groundingChunks.map((chunk, index) => (
                                        chunk.web && (
                                            <li key={chunk.web.uri + index} className="truncate">
                                                <a 
                                                    href={chunk.web.uri} 
                                                    target="_blank" 
                                                    rel="noopener noreferrer" 
                                                    className="text-blue-600 dark:text-blue-400 hover:underline"
                                                    title={chunk.web.title}
                                                >
                                                    {chunk.web.title || new URL(chunk.web.uri).hostname}
                                                </a>
                                            </li>
                                        )
                                    ))}
                                </ol>
                            </div>
                        )}

                        {/* Suggested Questions */}
                        {isLastModelMessage && !isSending && suggestions.length > 0 && (
                            <div className="flex flex-col items-start gap-2">
                                {suggestions.map((q, i) => (
                                    <button 
                                        key={i} 
                                        onClick={() => onSuggestedQuestionClick(q)}
                                        className="w-full text-left text-sm p-2 rounded-lg bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 transition-colors"
                                    >
                                        {q}
                                    </button>
                                ))}
                            </div>
                        )}
                    </div>
                )}
            </div>
            
             {isUser && message.status === 'error' && (
                <div className="self-center ml-2">
                    <button onClick={() => onRetry(message.id)} className="text-xs text-red-500 hover:underline">Subiramo</button>
                </div>
            )}
        </div>
    );
};

const MemoizedChatMessageItem = React.memo(ChatMessageItem, (prevProps, nextProps) => {
    // This custom comparison function prevents re-renders unless specific properties change.
    return (
        prevProps.message.id === nextProps.message.id &&
        prevProps.message.text === nextProps.message.text &&
        prevProps.message.status === nextProps.message.status &&
        JSON.stringify(prevProps.message.groundingChunks) === JSON.stringify(nextProps.message.groundingChunks) &&
        prevProps.isLastModelMessage === nextProps.isLastModelMessage &&
        prevProps.isSending === nextProps.isSending
    );
});


const ChatDisplay: React.FC<ChatDisplayProps> = ({ messages, onRetry, onRegenerate, onSuggestedQuestionClick, isSending }) => {
    const scrollRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const element = scrollRef.current;
        if (element) {
            // Only auto-scroll if user is near the bottom to avoid disrupting them
            const isScrolledToBottom = element.scrollHeight - element.clientHeight <= element.scrollTop + 100;
            if (isScrolledToBottom) {
                element.scrollTop = element.scrollHeight;
            }
        }
    }, [messages]);

    const lastModelMessageIndex = messages.map(m => m.role).lastIndexOf('model');
    
    if (messages.length === 0) {
        return (
            <div className="flex-1 overflow-y-auto p-4">
                <WelcomePlaceholder />
            </div>
        );
    }

    return (
        <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 chat-scroll-container">
            <div className="max-w-3xl mx-auto w-full space-y-6">
                {messages.map((message, index) => (
                    <MemoizedChatMessageItem
                        key={message.id}
                        message={message}
                        isLastModelMessage={index === lastModelMessageIndex}
                        isSending={isSending}
                        onRetry={onRetry}
                        onRegenerate={onRegenerate}
                        onSuggestedQuestionClick={onSuggestedQuestionClick}
                    />
                ))}
            </div>
        </div>
    );
};

export default ChatDisplay;
import React from 'react';
import { PaperClipIcon, CameraIcon, PaperAirplaneIcon, CopyIcon, RefreshIcon } from './icons';

const Legend: React.FC = () => {
    const legendItems = [
        { 
            Icon: PaperClipIcon, 
            description: 'Ongeraho ifoto cyangwa dosiye' 
        },
        { 
            Icon: CameraIcon, 
            description: 'Fata ifoto ukoresheje kamera' 
        },
        {
            Icon: PaperAirplaneIcon,
            description: 'Ohereza ubutumwa'
        },
        {
            Icon: CopyIcon,
            description: 'Koporora ubutumwa'
        },
        {
            Icon: RefreshIcon,
            description: 'Ongera usubize'
        }
    ];

    return (
        <div className="flex flex-wrap items-center justify-center gap-x-4 sm:gap-x-6 gap-y-2 p-3 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-200 dark:border-slate-700">
            {legendItems.map(({ Icon, description }) => (
                <div key={description} className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                    <Icon className="w-4 h-4 flex-shrink-0" />
                    <span>{description}</span>
                </div>
            ))}
        </div>
    );
};

export default Legend;
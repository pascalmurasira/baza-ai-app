import React, { useEffect, useRef } from 'react';
import { Cog8ToothIcon, XCircleIcon } from './icons';

interface SettingsModalProps {
    isOpen: boolean;
    onClose: () => void;
    theme: string;
    setTheme: (theme: string) => void;
}

const themes = [
    { id: 'light', name: 'Urumuri' },
    { id: 'dark', name: 'Umwijima' },
    { id: 'system', name: 'Sisitemu' },
];

const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose, theme, setTheme }) => {
    const modalRef = useRef<HTMLDivElement>(null);
    const closeButtonRef = useRef<HTMLButtonElement>(null);

    useEffect(() => {
        const handleKeyDown = (event: KeyboardEvent) => {
            if (event.key === 'Escape') {
                onClose();
            }
        };

        if (isOpen) {
            document.addEventListener('keydown', handleKeyDown);
            closeButtonRef.current?.focus();
        }

        return () => {
            document.removeEventListener('keydown', handleKeyDown);
        };
    }, [isOpen, onClose]);
    
    if (!isOpen) {
        return null;
    }

    return (
        <div 
            className="fixed inset-0 bg-black bg-opacity-60 z-50 flex items-center justify-center p-4 transition-opacity"
            role="dialog"
            aria-modal="true"
            aria-labelledby="settings-title"
            onClick={onClose}
        >
            <div
                ref={modalRef}
                className="bg-white dark:bg-slate-800 rounded-xl shadow-xl w-full max-w-md transform transition-all duration-200 scale-95 opacity-0 animate-fade-in-scale"
                style={{animationFillMode: 'forwards'}}
                onClick={(e) => e.stopPropagation()}
                tabIndex={-1}
            >
                <div className="flex items-center justify-between p-4 border-b dark:border-slate-700">
                    <div className="flex items-center gap-2">
                        <Cog8ToothIcon className="w-6 h-6 text-slate-600 dark:text-slate-300" />
                        <h3 id="settings-title" className="text-lg font-semibold text-slate-900 dark:text-slate-100">Igenamiterere</h3>
                    </div>
                    <button ref={closeButtonRef} onClick={onClose} className="p-1 rounded-full hover:bg-slate-200 dark:hover:bg-slate-700">
                        <XCircleIcon className="w-6 h-6 text-slate-500 dark:text-slate-400" />
                    </button>
                </div>
                
                <div className="p-6 space-y-6">
                     <div>
                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                           Amabara
                        </label>
                        <div className="flex items-center gap-2 rounded-lg bg-slate-100 dark:bg-slate-900 p-1">
                            {themes.map(t => (
                                <button
                                    key={t.id}
                                    onClick={() => setTheme(t.id)}
                                    className={`w-full text-center px-3 py-1.5 text-sm rounded-md transition-colors ${theme === t.id ? 'bg-white dark:bg-slate-700 shadow font-semibold' : 'hover:bg-white/50 dark:hover:bg-slate-700/50'}`}
                                >
                                    {t.name}
                                </button>
                            ))}
                        </div>
                    </div>
                </div>

                 <div className="px-6 py-4 bg-slate-50 dark:bg-slate-800/50 flex justify-end rounded-b-xl">
                    <button
                        type="button"
                        onClick={onClose}
                        className="w-full sm:w-auto inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-600 text-sm font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:focus:ring-offset-slate-800"
                    >
                       Funga
                    </button>
                </div>
            </div>
             <style>{`
              @keyframes fade-in-scale {
                from { opacity: 0; transform: scale(0.95); }
                to { opacity: 1; transform: scale(1); }
              }
              .animate-fade-in-scale {
                animation: fade-in-scale 0.2s ease-out;
              }
            `}</style>
        </div>
    );
};

export default SettingsModal;
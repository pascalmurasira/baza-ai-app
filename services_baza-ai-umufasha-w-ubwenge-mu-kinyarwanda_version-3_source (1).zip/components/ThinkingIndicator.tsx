import React, { useState, useEffect } from 'react';
import { Cog8ToothIcon } from './icons';

const thinkingSteps = [
    "Ndabitekerezaho...",       // Thinking...
    "Ndashakisha amakuru...", // Searching for information...
    "Ndahuza ibisubizo...",   // Synthesizing answers...
    "Ndimo nandika igisubizo cyawe...", // Writing your response...
];

const ThinkingIndicator: React.FC = () => {
    const [step, setStep] = useState(0);

    useEffect(() => {
        const interval = setInterval(() => {
            setStep((prevStep) => (prevStep + 1) % thinkingSteps.length);
        }, 2000); // Change step every 2 seconds

        return () => clearInterval(interval);
    }, []);

    return (
        <div className="flex items-center gap-3 text-slate-600 dark:text-slate-400">
            <Cog8ToothIcon className="w-5 h-5 animate-spin" />
            <span className="text-sm font-medium">{thinkingSteps[step]}</span>
        </div>
    );
};

export default ThinkingIndicator;

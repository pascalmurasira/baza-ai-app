import React, { useRef, useCallback, useEffect } from 'react';
import type { LiveServerMessage, LiveSession, Blob } from '@google/genai';
import { createLiveSession } from '../services/geminiService';
import { MicrophoneIcon, StopCircleIcon } from './icons';

// As per Gemini docs, an `encode` function is needed for audio data.
function encode(bytes: Uint8Array): string {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

// Helper to convert raw audio data to the required Blob format for the API.
function createBlob(data: Float32Array): Blob {
    const l = data.length;
    const int16 = new Int16Array(l);
    for (let i = 0; i < l; i++) {
        // The API expects 16-bit PCM data.
        int16[i] = data[i] * 32768;
    }
    return {
        data: encode(new Uint8Array(int16.buffer)),
        // The API requires this specific MIME type for audio streaming.
        mimeType: 'audio/pcm;rate=16000',
    };
}

interface MicrophoneButtonProps {
    isListening: boolean;
    setIsListening: (isListening: boolean) => void;
    onTranscriptionComplete: (text: string) => void;
    setInterimTranscription: (text: string) => void;
    voiceName: string;
    playAudio: (base64: string) => Promise<void>;
    stopAllAudio: () => void;
}

const MicrophoneButton: React.FC<MicrophoneButtonProps> = ({
    isListening,
    setIsListening,
    onTranscriptionComplete,
    setInterimTranscription,
    voiceName,
    playAudio,
    stopAllAudio
}) => {
    const sessionPromiseRef = useRef<Promise<LiveSession> | null>(null);
    const sessionRef = useRef<LiveSession | null>(null);
    const inputAudioContextRef = useRef<AudioContext | null>(null);
    const scriptProcessorRef = useRef<ScriptProcessorNode | null>(null);
    const mediaStreamSourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
    const streamRef = useRef<MediaStream | null>(null);
    const currentInputTranscription = useRef('');

    const stopListening = useCallback(async () => {
        if (!isListening) return;

        // Stop any currently playing audio from the model.
        stopAllAudio();

        // Gracefully release all audio resources.
        streamRef.current?.getTracks().forEach(track => track.stop());
        scriptProcessorRef.current?.disconnect();
        mediaStreamSourceRef.current?.disconnect();
        if (inputAudioContextRef.current?.state !== 'closed') {
            await inputAudioContextRef.current?.close();
        }

        // Close the Gemini session.
        sessionRef.current?.close();

        // Reset all refs and state.
        streamRef.current = null;
        scriptProcessorRef.current = null;
        mediaStreamSourceRef.current = null;
        inputAudioContextRef.current = null;
        sessionRef.current = null;
        sessionPromiseRef.current = null;
        
        setIsListening(false);
        
        // When stopped, send the final transcribed text to the parent.
        if (currentInputTranscription.current.trim()) {
            onTranscriptionComplete(currentInputTranscription.current.trim());
        }
        currentInputTranscription.current = '';

    }, [isListening, setIsListening, onTranscriptionComplete, stopAllAudio]);


    const startListening = useCallback(async () => {
        if (isListening) return;

        stopAllAudio();
        setIsListening(true);
        currentInputTranscription.current = '';
        setInterimTranscription(''); // Clear the parent's input field

        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            streamRef.current = stream;

            inputAudioContextRef.current = new (window.AudioContext || window.webkitAudioContext)({ sampleRate: 16000 });
            
            const sessionPromise = createLiveSession({
                onopen: () => {
                    const audioContext = inputAudioContextRef.current;
                    if (!audioContext) return;

                    const source = audioContext.createMediaStreamSource(stream);
                    mediaStreamSourceRef.current = source;
                    
                    const scriptProcessor = audioContext.createScriptProcessor(4096, 1, 1);
                    scriptProcessorRef.current = scriptProcessor;

                    scriptProcessor.onaudioprocess = (audioProcessingEvent) => {
                        const inputData = audioProcessingEvent.inputBuffer.getChannelData(0);
                        const pcmBlob = createBlob(inputData);
                        
                        // Per docs, use the session promise to avoid race conditions on initial connection.
                        sessionPromiseRef.current?.then((session) => {
                           session.sendRealtimeInput({ media: pcmBlob });
                        });
                    };
                    source.connect(scriptProcessor);
                    scriptProcessor.connect(audioContext.destination);
                },
                onmessage: async (message: LiveServerMessage) => {
                    if (message.serverContent?.inputTranscription) {
                         const newText = message.serverContent.inputTranscription.text;
                         currentInputTranscription.current += newText;
                         setInterimTranscription(currentInputTranscription.current);
                    }

                    const base64Audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
                    if (base64Audio) {
                        playAudio(base64Audio);
                    }
                },
                onerror: (e: ErrorEvent) => {
                    console.error('Live session error:', e);
                    stopListening();
                },
                onclose: () => {
                    if(isListening) { // Handle unexpected close
                        stopListening();
                    }
                },
            }, voiceName);

            sessionPromiseRef.current = sessionPromise;
            sessionRef.current = await sessionPromise;

        } catch (error) {
            console.error("Error starting microphone:", error);
            setIsListening(false);
        }
    }, [isListening, playAudio, setIsListening, setInterimTranscription, stopAllAudio, stopListening, voiceName]);

    // Cleanup effect to ensure resources are released on component unmount.
    useEffect(() => {
        return () => {
            stopListening();
        };
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const handleClick = useCallback(() => {
        if (isListening) {
            stopListening();
        } else {
            startListening();
        }
    }, [isListening, startListening, stopListening]);

    return (
        <button
            type="button"
            onClick={handleClick}
            className={`p-2 rounded-full transition-transform duration-200 self-center focus:outline-none ${
                isListening ? 'listening-animation' : ''
            }`}
            aria-label={isListening ? 'Hagarika gufata amajwi' : 'Kanda kugirango uvuge'}
            title={isListening ? 'Hagarika gufata amajwi' : 'Kanda kugirango uvuge'}
        >
            {isListening ? (
                <StopCircleIcon className="w-6 h-6 text-red-500" />
            ) : (
                <MicrophoneIcon className="w-6 h-6 text-slate-600 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400" />
            )}
        </button>
    );
};

export default MicrophoneButton;
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { PaperAirplaneIcon, RefreshIcon, XCircleIcon } from './icons';

interface CameraModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSend: (dataUrl: string, prompt: string) => void;
}

const CameraModal: React.FC<CameraModalProps> = ({ isOpen, onClose, onSend }) => {
    const videoRef = useRef<HTMLVideoElement>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const [stream, setStream] = useState<MediaStream | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [capturedImage, setCapturedImage] = useState<string | null>(null);
    const [prompt, setPrompt] = useState('');

    const stopStream = useCallback(() => {
        if (stream) {
            stream.getTracks().forEach(track => track.stop());
            setStream(null);
        }
    }, [stream]);

    const startStream = useCallback(async () => {
        stopStream(); // Stop any existing stream
        setError(null);
        setCapturedImage(null);
        setPrompt('');
        try {
            const mediaStream = await navigator.mediaDevices.getUserMedia({ 
                video: { facingMode: 'environment' } 
            });
            setStream(mediaStream);
            if (videoRef.current) {
                videoRef.current.srcObject = mediaStream;
            }
        } catch (err) {
            console.error("Error accessing camera:", err);
            setError("Ntibishoboye gufungura kamera. Reba niba warabyemereye muri 'browser settings'.");
        }
    }, [stopStream]);

    useEffect(() => {
        if (isOpen) {
            startStream();
        } else {
            stopStream();
        }
        return () => stopStream();
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [isOpen]);

    const handleCapture = () => {
        if (videoRef.current && canvasRef.current) {
            const video = videoRef.current;
            const canvas = canvasRef.current;
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            const context = canvas.getContext('2d');
            context?.drawImage(video, 0, 0, video.videoWidth, video.videoHeight);
            const dataUrl = canvas.toDataURL('image/jpeg');
            setCapturedImage(dataUrl);
            stopStream(); // Stop stream after capture to show preview
        }
    };
    
    const handleConfirm = () => {
        if (capturedImage) {
            onSend(capturedImage, prompt);
        }
    };

    const handleRetake = () => {
        setPrompt('');
        startStream();
    };

    if (!isOpen) return null;

    return (
        <div 
            className="fixed inset-0 bg-black bg-opacity-80 z-50 flex items-center justify-center p-4"
            onClick={onClose}
        >
            <div 
                className="bg-slate-900 rounded-xl shadow-xl w-full max-w-2xl text-white transform transition-all duration-200 scale-95 opacity-0 animate-fade-in-scale"
                style={{animationFillMode: 'forwards'}}
                onClick={(e) => e.stopPropagation()}
            >
                <div className="p-4 relative">
                     <h3 className="text-lg font-semibold text-center">Fata Ifoto</h3>
                    <button onClick={onClose} className="absolute top-2 right-2 p-1 rounded-full text-slate-300 hover:bg-slate-700">
                        <XCircleIcon className="w-8 h-8" />
                    </button>
                </div>
                <div className="relative aspect-video bg-black">
                    {error ? (
                        <div className="flex items-center justify-center h-full text-center text-red-400">{error}</div>
                    ) : (
                        <>
                            <video ref={videoRef} autoPlay playsInline className={`w-full h-full object-contain ${capturedImage ? 'hidden' : ''}`} />
                            {capturedImage && <img src={capturedImage} alt="Ifoto yafashwe" className="w-full h-full object-contain" />}
                        </>
                    )}
                    <canvas ref={canvasRef} className="hidden" />
                </div>
                <div className="p-4 bg-slate-800 flex justify-center items-center gap-4 rounded-b-xl">
                    {capturedImage ? (
                         <div className="flex items-center gap-2 w-full">
                            <button onClick={handleRetake} className="p-2 rounded-full hover:bg-slate-700" title="Ongera ufate indi foto">
                                <RefreshIcon className="w-6 h-6 text-white"/>
                            </button>
                            <input
                                type="text"
                                value={prompt}
                                onChange={(e) => setPrompt(e.target.value)}
                                onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); handleConfirm(); } }}
                                placeholder="Ongeraho ubutumwa (si ngombwa)..."
                                className="flex-1 w-full px-3 py-2 rounded-lg bg-slate-700 text-white border border-slate-600 focus:outline-none focus:ring-2 focus:ring-blue-500"
                                autoFocus
                            />
                            <button 
                                onClick={handleConfirm} 
                                className="p-2 rounded-full bg-blue-600 text-white transition-colors disabled:bg-blue-800 disabled:cursor-not-allowed" 
                                title="Ohereza ifoto"
                                disabled={!capturedImage}
                            >
                                <PaperAirplaneIcon className="w-6 h-6"/>
                            </button>
                        </div>
                    ) : (
                        <button onClick={handleCapture} disabled={!stream} className="w-16 h-16 rounded-full bg-white border-4 border-slate-400 disabled:opacity-50" aria-label="Fata ifoto">
                           <div className="w-full h-full rounded-full bg-white active:bg-slate-200"></div>
                        </button>
                    )}
                </div>
            </div>
             <style>{`
              @keyframes fade-in-scale {
                from { opacity: 0; transform: scale(0.95); }
                to { opacity: 1; transform: scale(1); }
              }
              .animate-fade-in-scale {
                animation: fade-in-scale 0.2s ease-out;
              }
            `}</style>
        </div>
    );
};

export default CameraModal;
import React, { useState, useRef, useCallback } from 'react';
import { editImage } from '../services/geminiService';
import { PhotoIcon, DownloadIcon, TrashIcon, PaperAirplaneIcon } from './icons';
import ThinkingIndicator from './ThinkingIndicator';

const ImageEditor: React.FC = () => {
    const [originalImage, setOriginalImage] = useState<{ name: string; type: string; dataUrl: string; } | null>(null);
    const [editedImage, setEditedImage] = useState<string | null>(null);
    const [prompt, setPrompt] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isDraggingOver, setIsDraggingOver] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const processFile = useCallback((file: File | undefined) => {
        if (file && file.type.startsWith('image/')) {
            const reader = new FileReader();
            reader.onload = (loadEvent) => {
                setOriginalImage({
                    name: file.name,
                    type: file.type,
                    dataUrl: loadEvent.target?.result as string,
                });
                setEditedImage(null);
                setError(null);
            };
            reader.readAsDataURL(file);
        } else {
            setError("Hitamo ifoto yemewe.");
        }
    }, []);

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        processFile(e.target.files?.[0]);
    };
    
    const handleDragEnter = (e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDraggingOver(true);
    };

    const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDraggingOver(false);
    };
    
    const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation(); // Necessary to allow drop
    };

    const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDraggingOver(false);
        const file = e.dataTransfer.files?.[0];
        if (file) {
            processFile(file);
        }
    };


    const handleGenerate = useCallback(async () => {
        if (!originalImage || !prompt.trim()) return;

        setIsLoading(true);
        setError(null);
        setEditedImage(null);

        try {
            const resultDataUrl = await editImage(prompt, originalImage);
            setEditedImage(resultDataUrl);
        } catch (err) {
            console.error("Image editing failed:", err);
            setError("Byananiwe guhindura ifoto. Nyamuneka ongera ugerageze.");
        } finally {
            setIsLoading(false);
        }
    }, [originalImage, prompt]);

    const handleReset = () => {
        setOriginalImage(null);
        setEditedImage(null);
        setPrompt('');
        setError(null);
        if (fileInputRef.current) {
            fileInputRef.current.value = '';
        }
    };
    
    const handleDownload = () => {
        if (!editedImage) return;
        const link = document.createElement('a');
        link.href = editedImage;
        link.download = `edited_${originalImage?.name || 'image.png'}`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    return (
        <div className="flex-1 flex flex-col bg-slate-50 dark:bg-slate-900/50">
            <div className="flex-1 overflow-y-auto p-4 sm:p-8 flex items-center justify-center">
                <div className="w-full max-w-4xl mx-auto">
                    {!originalImage ? (
                        <div className="text-center">
                            <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" accept="image/*" />
                            <div 
                                onClick={() => fileInputRef.current?.click()}
                                onDrop={handleDrop}
                                onDragOver={handleDragOver}
                                onDragEnter={handleDragEnter}
                                onDragLeave={handleDragLeave}
                                className={`flex flex-col items-center justify-center w-full h-64 border-2 border-dashed rounded-lg cursor-pointer transition-colors 
                                ${isDraggingOver 
                                    ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/50' 
                                    : 'border-slate-300 dark:border-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800'
                                }`}
                            >
                                <PhotoIcon className={`w-16 h-16 mb-4 transition-colors ${isDraggingOver ? 'text-blue-600 dark:text-blue-400' : 'text-slate-400 dark:text-slate-500'}`} />
                                <span className={`text-lg font-semibold transition-colors ${isDraggingOver ? 'text-blue-700 dark:text-blue-300' : 'text-slate-600 dark:text-slate-300'}`}>Ongeraho Ifoto</span>
                                <p className={`text-sm mt-1 transition-colors ${isDraggingOver ? 'text-blue-600 dark:text-blue-400' : 'text-slate-500 dark:text-slate-400'}`}>
                                    {isDraggingOver ? 'Rekura ifoto hano' : 'Kanda hano cyangwa kurura ifoto uyishyire hano'}
                                </p>
                            </div>
                            {error && <p className="mt-4 text-sm text-red-500">{error}</p>}
                        </div>
                    ) : (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-8 items-start">
                             <div className="space-y-4">
                                <h3 className="text-lg font-semibold text-slate-700 dark:text-slate-200">Ifoto y'umwimerere</h3>
                                <div className="relative aspect-square bg-slate-200 dark:bg-slate-800 rounded-lg overflow-hidden">
                                     <img src={originalImage.dataUrl} alt="Original" className="w-full h-full object-contain" />
                                </div>
                             </div>
                             <div className="space-y-4">
                                <h3 className="text-lg font-semibold text-slate-700 dark:text-slate-200">Ifoto yahinduwe</h3>
                                <div className="relative aspect-square bg-slate-200 dark:bg-slate-800 rounded-lg flex items-center justify-center overflow-hidden">
                                    {isLoading && <ThinkingIndicator />}
                                    {error && !isLoading && <div className="p-4 text-center text-red-500">{error}</div>}
                                    {editedImage && !isLoading && <img src={editedImage} alt="Edited" className="w-full h-full object-contain" />}
                                    {!isLoading && !editedImage && !error && <div className="text-slate-500">Igisubizo kizagaragara hano</div>}
                                </div>
                             </div>
                        </div>
                    )}
                </div>
            </div>
            
            <div className="p-2 sm:p-4 border-t border-slate-200 dark:border-slate-700">
                <div className="max-w-4xl mx-auto">
                    {originalImage && (
                        <div className="flex items-center gap-2 sm:gap-4">
                            <button onClick={handleReset} className="p-2 rounded-full hover:bg-slate-200 dark:hover:bg-slate-700" title="Hindura ifoto">
                                <TrashIcon className="w-6 h-6 text-red-500" />
                            </button>
                            <input
                                value={prompt}
                                onChange={(e) => setPrompt(e.target.value)}
                                onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleGenerate(); } }}
                                placeholder="Urugero: Hindura inyuma hashyirweho umukororombya..."
                                className="flex-1 p-2 rounded-lg bg-slate-100 dark:bg-slate-800 resize-none focus:outline-none focus:ring-2 focus:ring-blue-500"
                                disabled={isLoading}
                            />
                            {editedImage && !isLoading ? (
                                <button onClick={handleDownload} className="p-2 rounded-full bg-green-600 text-white" title="Vana ifoto kuri mudasobwa">
                                    <DownloadIcon className="w-6 h-6"/>
                                </button>
                            ) : (
                                <button
                                    onClick={handleGenerate}
                                    disabled={isLoading || !prompt.trim()}
                                    className="p-2 rounded-full bg-blue-600 text-white transition-colors disabled:bg-blue-300 dark:disabled:bg-blue-800 disabled:cursor-not-allowed"
                                    title="Hindura ifoto"
                                >
                                    <PaperAirplaneIcon className="w-6 h-6" />
                                </button>
                            )}
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default ImageEditor;
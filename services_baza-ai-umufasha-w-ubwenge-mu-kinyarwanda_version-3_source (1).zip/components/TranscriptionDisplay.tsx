import React from 'react';

interface TranscriptionDisplayProps {
    transcription: string;
    isListening: boolean;
}

const TranscriptionDisplay: React.FC<TranscriptionDisplayProps> = ({ transcription, isListening }) => {
    if (!isListening || !transcription) {
        return null;
    }
    
    return (
        <div className="px-2 sm:px-4 py-2 bg-slate-100 dark:bg-slate-900 border-t border-b dark:border-slate-700">
            <p className="text-sm text-slate-600 dark:text-slate-300">
                <span className="font-semibold mr-1">Uri kuvuga:</span>
                <span className="italic">{transcription}</span>
            </p>
        </div>
    );
};

export default TranscriptionDisplay;

import React, { useState, useRef, useEffect, useMemo } from 'react';
import { Cog8ToothIcon, TrashIcon, PlusIcon, PencilIcon, CheckIcon, DownloadIcon, SearchIcon, XCircleIcon } from './icons';
import { ChatSession } from '../types';
import ConfirmClearModal from './ConfirmClearModal';

interface SidebarProps {
    sessions: ChatSession[];
    currentChatId?: string | null;
    onNewChat: () => void;
    onSelectChat: (id: string) => void;
    onDeleteChat: (id: string) => void;
    onUpdateChatTitle: (id: string, title: string) => void;
    onSettings: () => void;
    isOpen: boolean;
    setIsOpen: (isOpen: boolean) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ sessions, currentChatId, onNewChat, onSelectChat, onDeleteChat, onUpdateChatTitle, onSettings, isOpen, setIsOpen }) => {
    const [editingId, setEditingId] = useState<string | null>(null);
    const [editingTitle, setEditingTitle] = useState('');
    const [deletingId, setDeletingId] = useState<string | null>(null);
    const [searchQuery, setSearchQuery] = useState('');
    const inputRef = useRef<HTMLInputElement>(null);

    useEffect(() => {
        if (editingId && inputRef.current) {
            inputRef.current.focus();
            inputRef.current.select();
        }
    }, [editingId]);
    
    const filteredSessions = useMemo(() => {
        if (!searchQuery.trim()) {
            return sessions;
        }
        const query = searchQuery.toLowerCase();
        return sessions.filter(session => {
            const titleMatch = session.title.toLowerCase().includes(query);
            if (titleMatch) return true;

            const contentMatch = session.messages.some(message =>
                message.text && message.text.toLowerCase().includes(query)
            );
            return contentMatch;
        });
    }, [sessions, searchQuery]);

    const handleEdit = (session: ChatSession) => {
        setEditingId(session.id);
        setEditingTitle(session.title);
    };

    const handleSaveTitle = (id: string) => {
        if (editingTitle.trim()) {
            onUpdateChatTitle(id, editingTitle.trim());
        }
        setEditingId(null);
    };

    const handleDelete = () => {
        if(deletingId) {
            onDeleteChat(deletingId);
            setDeletingId(null);
        }
    };
    
    const handleDownloadChat = (session: ChatSession) => {
        const formatTimestamp = (ts: number) => new Date(ts).toLocaleString('rw-RW', {
            year: 'numeric', month: '2-digit', day: '2-digit',
            hour: '2-digit', minute: '2-digit',
        });

        let content = `Umutwe w'ikiganiro: ${session.title}\n`;
        content += `Gishya kuri: ${formatTimestamp(session.createdAt)}\n`;
        content += '====================================\n\n';

        session.messages.forEach(msg => {
            if (msg.status === 'pending') return;

            const prefix = msg.role === 'user' ? 'Wowe' : 'Baza AI';
            const timestamp = msg.timestamp ? ` [${formatTimestamp(msg.timestamp)}]` : '';
            
            content += `${prefix}${timestamp}\n`;
            if (msg.file) {
                content += `(Ifayili yometseho: ${msg.file.name})\n`;
            }
            
            let messageText = msg.text;
            if (msg.role === 'model' && messageText.includes('[SUGGESTIONS]')) {
                messageText = messageText.split('[SUGGESTIONS]')[0].trim();
            }

            content += `${messageText}\n\n`;
        });

        const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        const sanitizedTitle = session.title.replace(/ /g, '-').replace(/[^a-z0-9-]/gi, '_').toLowerCase();
        link.download = `baza_ai_${sanitizedTitle}.txt`;
        link.href = url;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    };

    return (
        <>
            <div className={`fixed inset-0 bg-black bg-opacity-50 z-30 md:hidden transition-opacity ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`} onClick={() => setIsOpen(false)}></div>
            <aside className={`fixed top-0 left-0 h-full w-64 bg-slate-50 dark:bg-slate-800/80 dark:backdrop-blur-sm border-r border-slate-200 dark:border-slate-700/50 p-4 flex flex-col z-40 transform transition-transform md:translate-x-0 ${isOpen ? 'translate-x-0' : '-translate-x-full'}`}>
                <div className="mb-4">
                     <h1 className="text-xl font-bold text-center">Baza AI</h1>
                </div>
                
                <button
                    onClick={onNewChat}
                    className="w-full flex items-center justify-center gap-2 px-4 py-2 mb-4 text-sm font-semibold text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors"
                    title="Tangira ikiganiro gishya"
                >
                    <PlusIcon className="w-4 h-4" />
                    Ikiganiro Gishya
                </button>

                <div className="relative my-2">
                    <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                        <SearchIcon className="w-4 h-4 text-slate-400" />
                    </div>
                    <input
                        type="text"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="Shakisha ibiganiro..."
                        className="w-full pl-9 pr-8 py-2 text-sm bg-slate-100 dark:bg-slate-700/50 rounded-lg border border-transparent focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                    {searchQuery && (
                        <button
                            onClick={() => setSearchQuery('')}
                            className="absolute inset-y-0 right-0 flex items-center pr-3"
                            title="Siba ibyashatswe"
                        >
                            <XCircleIcon className="w-4 h-4 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200" />
                        </button>
                    )}
                </div>

                <div className="flex-1 overflow-y-auto -mr-2 pr-2 space-y-1 mt-2">
                    {filteredSessions.map(session => {
                        const lastMessage = session.messages.slice().reverse().find(m => m.text && m.status !== 'pending');
                        const previewText = lastMessage
                            ? `${lastMessage.role === 'user' ? 'Wowe: ' : ''}${lastMessage.text}`
                            : 'Tangira ikiganiro...';

                        return (
                            <div key={session.id} className={`group w-full flex items-center justify-between rounded-lg transition-colors ${currentChatId === session.id ? 'bg-blue-100 dark:bg-blue-900/50' : 'hover:bg-slate-200 dark:hover:bg-slate-700/50'}`}>
                               {editingId === session.id ? (
                                    <input
                                        ref={inputRef}
                                        type="text"
                                        value={editingTitle}
                                        onChange={(e) => setEditingTitle(e.target.value)}
                                        onBlur={() => handleSaveTitle(session.id)}
                                        onKeyDown={(e) => e.key === 'Enter' && handleSaveTitle(session.id)}
                                        className="w-full bg-transparent px-3 py-2 text-sm focus:outline-none"
                                    />
                               ) : (
                                    <button onClick={() => onSelectChat(session.id)} className="flex-1 text-left px-3 py-2 text-sm overflow-hidden">
                                        <div className="font-semibold truncate">{session.title}</div>
                                        <p className="text-xs text-slate-500 dark:text-slate-400 truncate mt-1">
                                            {previewText}
                                        </p>
                                    </button>
                               )}
                               
                                <div className="flex items-center pr-2">
                                    {editingId === session.id ? (
                                        <button onClick={() => handleSaveTitle(session.id)} className="p-1 text-slate-500 hover:text-green-600"><CheckIcon className="w-4 h-4"/></button>
                                    ) : (
                                        <>
                                            <button onClick={() => handleDownloadChat(session)} className="p-1 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 opacity-0 group-hover:opacity-100 transition-opacity" title="Vana ikiganiro kuri mudasobwa"><DownloadIcon className="w-4 h-4"/></button>
                                            <button onClick={() => handleEdit(session)} className="p-1 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 opacity-0 group-hover:opacity-100 transition-opacity"><PencilIcon className="w-4 h-4"/></button>
                                            <button onClick={() => setDeletingId(session.id)} className="p-1 text-slate-500 hover:text-red-600 opacity-0 group-hover:opacity-100 transition-opacity"><TrashIcon className="w-4 h-4"/></button>
                                        </>
                                    )}
                                </div>
                            </div>
                        )
                    })}
                </div>
                
                <div className="mt-auto">
                    <button
                        onClick={onSettings}
                        className="w-full flex items-center gap-3 px-3 py-2 text-sm text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors"
                        title="Fungura igenamiterere"
                    >
                        <Cog8ToothIcon className="w-5 h-5" />
                        <span>Igenamiterere</span>
                    </button>

                    <div className="mt-4 pt-4 border-t border-slate-200 dark:border-slate-700/50 text-center">
                        <p className="text-xs text-slate-500 dark:text-slate-400 mb-2 px-2">
                            Baza AI ishobora kwibeshya. Nyamuneka genzura amakuru y'ingenzi.
                        </p>
                    </div>
                </div>
            </aside>
             <ConfirmClearModal
                isOpen={!!deletingId}
                onClose={() => setDeletingId(null)}
                onConfirm={handleDelete}
                title="Siba ikiganiro"
                confirmText="Siba"
                confirmColor="red"
            >
                Urifuza gusiba burundu iki kiganiro?
            </ConfirmClearModal>
        </>
    );
};

export default Sidebar;
import React, { useEffect, useRef } from 'react';
import { ExclamationTriangleIcon } from './icons';

interface ConfirmClearModalProps {
    isOpen: boolean;
    onClose: () => void;
    onConfirm: () => void;
    title: string;
    children: React.ReactNode;
    confirmText?: string;
    confirmColor?: 'red' | 'blue';
}

const ConfirmClearModal: React.FC<ConfirmClearModalProps> = ({ 
    isOpen, 
    onClose, 
    onConfirm, 
    title, 
    children,
    confirmText = "Siba",
    confirmColor = 'red'
}) => {
    const modalRef = useRef<HTMLDivElement>(null);
    const confirmButtonRef = useRef<HTMLButtonElement>(null);

    useEffect(() => {
        const handleKeyDown = (event: KeyboardEvent) => {
            if (event.key === 'Escape') {
                onClose();
            }
        };

        if (isOpen) {
            document.addEventListener('keydown', handleKeyDown);
            // Focus the confirm button by default for accessibility, as it's the destructive action.
            confirmButtonRef.current?.focus();
        }

        return () => {
            document.removeEventListener('keydown', handleKeyDown);
        };
    }, [isOpen, onClose]);

    if (!isOpen) {
        return null;
    }

    const colorClasses = {
        red: {
            iconContainer: 'bg-red-100 dark:bg-red-900/50',
            icon: 'text-red-600 dark:text-red-400',
            button: 'bg-red-600 hover:bg-red-700 focus:ring-red-500',
        },
        blue: {
            iconContainer: 'bg-blue-100 dark:bg-blue-900/50',
            icon: 'text-blue-600 dark:text-blue-400',
            button: 'bg-blue-600 hover:bg-blue-700 focus:ring-blue-500',
        }
    }
    const colors = colorClasses[confirmColor];

    return (
        <div 
            className="fixed inset-0 bg-black bg-opacity-60 z-50 flex items-center justify-center p-4 transition-opacity"
            role="dialog"
            aria-modal="true"
            aria-labelledby="confirm-title"
            onClick={onClose}
        >
            <div
                ref={modalRef}
                className="bg-white dark:bg-slate-800 rounded-xl shadow-xl w-full max-w-sm transform transition-all duration-200 scale-95 opacity-0 animate-fade-in-scale"
                style={{animationFillMode: 'forwards'}}
                onClick={(e) => e.stopPropagation()}
                tabIndex={-1}
            >
                <div className="p-6 text-center">
                    <div className={`mx-auto flex items-center justify-center h-12 w-12 rounded-full ${colors.iconContainer}`}>
                        <ExclamationTriangleIcon className={`h-6 w-6 ${colors.icon}`} aria-hidden="true" />
                    </div>
                    <div className="mt-3">
                        <h3 id="confirm-title" className="text-lg font-semibold text-slate-900 dark:text-slate-100">{title}</h3>
                        <div className="mt-2">
                            <p className="text-sm text-slate-500 dark:text-slate-400">
                                {children}
                            </p>
                        </div>
                    </div>
                </div>
                
                <div className="px-6 py-4 bg-slate-50 dark:bg-slate-800/50 flex flex-col-reverse sm:flex-row sm:justify-center gap-3 rounded-b-xl">
                    <button
                        type="button"
                        onClick={onClose}
                        className="w-full sm:w-auto inline-flex justify-center rounded-md border border-slate-300 dark:border-slate-600 shadow-sm px-4 py-2 bg-white dark:bg-slate-700 text-sm font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:focus:ring-offset-slate-800"
                    >
                        Bireke
                    </button>
                    <button
                        ref={confirmButtonRef}
                        type="button"
                        onClick={onConfirm}
                        className={`w-full sm:w-auto inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 text-sm font-medium text-white focus:outline-none focus:ring-2 focus:ring-offset-2 dark:focus:ring-offset-slate-800 ${colors.button}`}
                    >
                        {confirmText}
                    </button>
                </div>
            </div>
             <style>{`
              @keyframes fade-in-scale {
                from { opacity: 0; transform: scale(0.95); }
                to { opacity: 1; transform: scale(1); }
              }
              .animate-fade-in-scale {
                animation: fade-in-scale 0.2s ease-out;
              }
            `}</style>
        </div>
    );
};

export default ConfirmClearModal;

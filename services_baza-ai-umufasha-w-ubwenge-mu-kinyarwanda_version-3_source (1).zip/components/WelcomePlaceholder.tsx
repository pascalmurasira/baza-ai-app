import React from 'react';

const WelcomePlaceholder: React.FC = () => {
    return (
        <div className="flex flex-col items-center justify-center h-full text-center text-slate-500 dark:text-slate-400">
            <h2 className="text-2xl font-bold mb-4 text-slate-700 dark:text-slate-200">Baza AI</h2>
        </div>
    );
};

export default WelcomePlaceholder;

import { GoogleGenAI, Chat, GenerateContentResponse, Content, Part, LiveSession, LiveServerMessage, Modality } from '@google/genai';
import type { GroundingChunk } from '../types';

let ai: GoogleGenAI;

function getAI() {
    if (!ai) {
        ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    }
    return ai;
}

// Fix: Refactored system instruction into a constant to be shared.
// Base system instruction in Kinyarwanda to guide the AI's personality and behavior.
const SYSTEM_INSTRUCTION = `
Uri umufasha w'ubwenge witwa Baza AI. Uvuga Ikinyarwanda neza.

AMATEGEKO Y'INGENZI:
1. SUBIZA MU KINYARWANDA GUSA. Ntukigere na rimwe wandika mu Cyongereza keretse iyo usabwe gusobanura ijambo.
2. HISHA UBURYO UTEKEREZA: ITEGEKO RIKOMEYE: Ntukigere na rimwe wandika uburyo utekereza (thinking process). Ntukandike amagambo nka "The user is asking..." cyangwa "I will use the search tool...". Hita utanga igisubizo cya nyuma mu Kinyarwanda GUSA. Icyo wandika kigomba guhita gitangira n'igisubizo nyirizina.
3. KORESHA UBUSHAKASHATSI: Koresha buri gihe igikoresho cy'ubushakashatsi (search tool) ku bibazo byerekeye itariki y'uyu munsi, isaha, ibyabaye vuba, cyangwa andi makuru ashobora kuba yaragize impinduka vuba kugira ngo igisubizo cyawe kibe ari cyo kandi kigezweho.

Tanga ibisubizo nyabyo, bifasha, kandi bitekanye. Ku makuru agezweho, nifashisha ubushakashatsi kuri interineti kugira ngo nguhe amakuru ya nyayo.

Itegeko ryo Gusobanura Urujijo:
Igihe ikibazo cy'ukoresha giteye urujijo, vuga ko utagifiteho amakuru yose ariko utange igisubizo gishingiye kubyo uzi.

Amabwiriza yo Gutanga Ibitekerezo By'ibibazo bikurikiraho:
Nyuma yo gutanga igisubizo cyawe cy'ibanze, reba witonze niba ibibazo bikurikiraho byaba bifitiye umumaro ukoresha.
Tanga ibitekerezo by'ibibazo GUSA IGIHE ikibazo cy'ukoresha kigaragaza ubushake bwo kwiga, gushakisha, cyangwa kuganira byimbitse. Urugero: ibibazo byerekeye amateka, siyanse, gutegura ikintu, cyangwa gusaba ibisobanuro.
NTUGATANGE ibitekerezo by'ibibazo ku ndamukanyo zoroshye, amagambo yo gushima, cyangwa ibibazo bigufi aho ikiganiro kigaragara ko kirangiye. Urugero: niba ukoresha avuze "Murakoze", ntuzongereho ibindi bibazo.
Igihe utanze ibyo bitekezo, tanga ibibazo bibiri cyangwa bitatu bijyanye n'ingingo. Bigomba gutangwa mu buryo bukurikira ku murongo uheruka w'igisubizo cyawe, ntuzongereho ikindi kintu nyuma yabyo:
[SUGGESTIONS]
* Ikibazo cya 1?
* Ikibazo cya 2?
* Ikibazo cya 3?
    `.trim();

export async function startChat(history: Content[]): Promise<Chat> {
    const ai = getAI();

    const chat = ai.chats.create({
        model: 'gemini-2.5-flash',
        history,
        config: {
            systemInstruction: SYSTEM_INSTRUCTION,
            tools: [{ googleSearch: {} }],
        },
    });
    return chat;
}

export async function sendMessage(
    chat: Chat, 
    message: string, 
    file: { type: string; dataUrl: string } | undefined,
    onChunk: (text: string) => void
): Promise<{ text: string; groundingChunks: GroundingChunk[] }> {
    const parts: Part[] = [{ text: message }];

    if (file) {
        const base64Data = file.dataUrl.split(',')[1];
        parts.unshift({
            inlineData: {
                data: base64Data,
                mimeType: file.type,
            },
        });
    }
    
    const stream = await chat.sendMessageStream({ message: parts });

    let fullText = "";
    const groundingChunksMap = new Map<string, GroundingChunk>();

    for await (const chunk of stream) {
        const chunkText = chunk.text;
        if (chunkText) {
            fullText += chunkText;
            // This regex identifies and removes the internal tool-use monologue
            // that the model sometimes outputs before the actual response.
            // It looks for the "tool_code" and "thought" keywords.
            const cleanedText = fullText.replace(/^tool_code[\s\S]*?thought[\s\S]*?(\n|$)/, '').trimStart();
            
            onChunk(cleanedText);
        }

        const chunks = chunk.candidates?.[0]?.groundingMetadata?.groundingChunks;
        if (chunks) {
            for (const gc of chunks) {
                if (gc.web?.uri && !groundingChunksMap.has(gc.web.uri)) {
                    groundingChunksMap.set(gc.web.uri, gc as GroundingChunk);
                }
            }
        }
    }
    
    const finalText = fullText.replace(/^tool_code[\s\S]*?thought[\s\S]*?(\n|$)/, '').trimStart();
    const finalGroundingChunks = Array.from(groundingChunksMap.values());

    return { text: finalText, groundingChunks: finalGroundingChunks };
}

// Fix: Added missing `editImage` function for image editing capabilities.
export async function editImage(
    prompt: string,
    image: { type: string; dataUrl: string; }
): Promise<string> {
    const ai = getAI();
    const base64Data = image.dataUrl.split(',')[1];

    const imagePart = {
        inlineData: {
            data: base64Data,
            mimeType: image.type,
        },
    };

    const textPart = {
        text: prompt,
    };

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: {
            parts: [imagePart, textPart],
        },
        config: {
            responseModalities: [Modality.IMAGE],
        },
    });

    for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
            const base64ImageBytes: string = part.inlineData.data;
            const mimeType = part.inlineData.mimeType;
            return `data:${mimeType};base64,${base64ImageBytes}`;
        }
    }

    throw new Error("No image was generated by the model.");
}

// Fix: Added missing `createLiveSession` function to support audio streaming.
export function createLiveSession(
    callbacks: {
        onopen: () => void;
        onmessage: (message: LiveServerMessage) => Promise<void>;
        onerror: (e: ErrorEvent) => void;
        onclose: (e: CloseEvent) => void;
    },
    voiceName: string
): Promise<LiveSession> {
    const ai = getAI();

    const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        callbacks,
        config: {
            responseModalities: [Modality.AUDIO],
            speechConfig: {
                voiceConfig: { prebuiltVoiceConfig: { voiceName } },
            },
            inputAudioTranscription: {}, // To get user's speech as text
            systemInstruction: SYSTEM_INSTRUCTION,
        },
    });

    return sessionPromise;
}